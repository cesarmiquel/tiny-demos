"Floorcast 32b"
32 bytes intro for msdos
by HellMood / DESiRE
for Chaos Construction 2018

-----------------------------------
 world first perspective projection
 of a 2D textured plane in 32 bytes
 best attempt so far in 64 bytes : 
 "floorcast64" by Baudsurfer (2014)

  ♥ greetings to all sizecoders ♥
-----------------------------------

floorcast64 reference:
https://www.pouet.net/prod.php?which=63305

the intro is designed to work on
- DosBox 0.74
- Windows XP (Dos/ntvdm)
- MSDOS (6 or above)
- FreeDos

most likely it will be WAY too fast
on a modern compo machine. that's why
i included a portable DOSBox with the
release. Simply execute the 

     ! ! !  s t a r t  ! ! !.bat
	 
it will launch DosBox in FullScreen
and execute "Floor32.com". Press
"STRG + F9" to end dosbox


contact me :
helmut.toedtmann@gmail.com