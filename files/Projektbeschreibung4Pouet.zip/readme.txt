     Projektbeschreibung
     -------------------

     32 byte MSDOS entry

       by HellMood 
           & Sensenstahl
	  
       for DiHalt 2018
  
Please execute on one of these:
        - FreeDos
        - MsDos
        - DosBox
        - WinXP Dos

     NO ESCAPE SUPPORT !
 sorry, but it's 32 bytes ;)

   should look like this :
 https://youtu.be/eSXMCQiNOIc

   *** Bonus Versions ***
pro-esc : original, ESC support
pro-max : 45-75 planes (original)
pro-rec : ~220 planes with rects
